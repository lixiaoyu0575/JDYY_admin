import { Component } from '@angular/core';

@Component({
  selector: 'report',
  template:
  '<router-outlet></router-outlet>',
  // Angular insists that we declare a target property to be an input property.
})

export class ReportComponent {

}
